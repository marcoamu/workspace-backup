# Sistema MiBimax - Mejoras 28 Marzo 2026

## ✅ Servicios Activos

| Servicio | Puerto | Estado |
|----------|--------|--------|
| Frontend | 3000 | ✅ OK |
| Backend | 8000 | ✅ OK |
| PostgreSQL | 5432 | ✅ OK |
| Redis | 6379 | ✅ OK |

## 🆕 Nuevas Funcionalidades

### Dashboard Métricas
- Endpoint: `/api/metrics/dashboard`
- Vista: Dashboard.vue

### Plan Usage Tracker  
- Vista: PlanUsage.vue
- Endpoint: `/api/metrics/usage`

### Sistema Alertas Telegram
- Script: telegram_alerts.sh
- Usa OpenClaw broadcast

### Auto-Restart
- Cada 2 minutos
- Script: auto_restart.sh

## 📊 Crons

| Hora | Task |
|------|------|
| */2 min | Auto-restart |
| 30 * * * | Smart alerts |
| 0 9 * * * | Daily memory |
| 0 3 * * * | Auto-improve |

## 🎯 Modelo: MiniMax-M2.7

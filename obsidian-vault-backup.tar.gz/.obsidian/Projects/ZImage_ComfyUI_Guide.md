# 🎨 ZImage/ComfyUI - Guía Completa de Prompts

## 📋 Parámetros Principales

### 1. ILUMINACIÓN (Lighting)
| Parámetro | Descripción | Valores |
|-----------|-------------|---------|
| cinematic lighting | Iluminación cinematográfica | - |
| volumetric fog | Niebla volumétrica | - |
| bokeh | Efecto de desenfoque | - |
| golden hour | Hora dorada | - |
| dramatic shadows | Sombras dramáticas | - |
| studio lighting | Iluminación de estudio | - |
| natural light | Luz natural | - |
| sunset lighting | Luz de atardecer | - |
| rim light | Luz de borde | - |
| softbox lighting | Luz de softbox | - |

### 2. ENTORNO (Environment)
| Parámetro | Descripción |
|-----------|-------------|
| foggy forest | Bosque nevado |
| urban environment | Entorno urbano |
| indoor scene | Escena interior |
| outdoor scene | Escena exterior |
| underwater scene | Escena submarina |
| space environment | Entorno espacial |
| desert landscape | Paisaje desértico |
| mountain landscape | Paisaje montañoso |

### 3. CÁMARA (Camera)
| Parámetro | Descripción | Valores |
|-----------|-------------|---------|
| wide angle | Ángulo amplio | - |
| extreme wide-angle | Ángulo extremo | - |
| telephoto | Teleobjetivo | - |
| macro | Macro | - |
| extreme close-up | Primer plano extremo | - |
| bird's eye view | Vista de pájaro | - |
| worm's eye view | Vista de gusano | - |
| low angle | Ángulo bajo | - |
| high angle | Ángulo alto | - |
| eye level | Nivel de ojos | - |

### 4. PROFUNDIDAD (Depth)
| Parámetro | Descripción |
|-----------|-------------|
| shallow depth of field | Profundidad de campo shallow |
| deep depth of field | Profundidad de campo profunda |
| bokeh | Efecto bokeh |
| tilt-shift | Efecto tilt-shift |

### 5. COLOR (Color)
| Parámetro | Descripción |
|-----------|-------------|
| vibrant colors | Colores vibrantes |
| muted tones | Tonos apagados |
| warm colors | Colores cálidos |
| cool colors | Colores fríos |
| high contrast | Alto contraste |
| low contrast | Bajo contraste |
| color grading | Gradación de color |
| teal and orange | Tonos azul y naranja |
| cinematic color | Color cinematográfico |

### 6. CALIDAD (Quality)
| Parámetro | Descripción |
|-----------|-------------|
| 8k resolution | Resolución 8k |
| 4k resolution | Resolución 4k |
| highly detailed | Altamente detallado |
| intricate details | Detalles intrincados |
| sharp focus | Enfoque nítido |
| masterpiece | Obra maestra |
| photorealistic | Fotorrealista |
| ultra realistic | Ultra fotorrealista |

### 7. ESTILO ARTÍSTICO (Art Style)
| Parámetro | Descripción |
|-----------|-------------|
| digital art | Arte digital |
| oil painting | Estilo óleo |
| watercolor | Acuarela |
| 3d render | Render 3d |
| unreal engine | Unreal Engine |
| octane render | Octane Render |
| vray | V-Ray |
| cinema 4d | Cinema 4D |
| concept art | Arte conceptual |
| illustration | Ilustración |
| anime | Estilo anime |
| manga | Manga |

### 8. COMPOSICIÓN (Composition)
| Parámetro | Descripción |
|-----------|-------------|
| rule of thirds | Regla de los tercios |
| centered composition | Composición centrada |
| leading lines | Líneas guía |
| rule of odds | Regla de los impares |
| negative space | Espacio negativo |
| framing | Encuadre |
| symmetry | Simetría |
| asymmetry | Asimetría |

### 9. ASPECTO (Aspect Ratio)
| Parámetro | Formato |
|-----------|---------|
| portrait | Retrato (9:16) |
| landscape | Paisaje (16:9) |
| square | Cuadrado (1:1) |
| ultrawide | Ultra ancho (21:9) |
| 4:3 | Formato clásico |
| 3:2 | Formato foto |

### 10. MOOD/ATMÓSFERA
| Parámetro | Descripción |
|-----------|-------------|
| dark mood | Ambiente oscuro |
| bright mood | Ambiente brillante |
| mysterious | Misterioso |
| peaceful | Tranquilo |
| dramatic | Dramático |
| romantic | Romántico |
| melancholic | Melancólico |
| energetic | Energético |

---

## 📝 Plantilla Base para ComfyUI

```
{{idea}}, {{lighting}}, {{environment}}, {{mood}}, {{camera_angle}}, {{depth_of_field}}, {{color_grading}}, {{style}}, {{quality}}, {{composition}}, {{aspect_ratio}}, 8k, highly detailed, professional photography
```

---

## 🔧 Valores por Defecto Recomendados

### Para Retratos:
```
{{idea}}, soft studio lighting, neutral background, shallow depth of field, rule of thirds, warm color grading, 8k, highly detailed, sharp focus, portrait photography
```

### Para Paisajes:
```
{{idea}}, golden hour lighting, outdoor environment, deep depth of field, wide angle, cinematic color, landscape photography, 8k, intricate details
```

### Para Arte Conceptual:
```
{{idea}}, dramatic lighting, volumetric fog, concept art style, digital painting, rule of thirds, 4k, highly detailed, unreal engine render
```

### Para Productos:
```
{{idea}}, product photography, studio lighting, white background, sharp focus, rule of thirds, clean color grading, 8k, e-commerce ready
```

---

## 🚀 Ejemplo de Prompt Completo

**Idea:** Un dragón mecánico volando sobre una ciudad futurista

**Prompt generado:**
```
A mechanical dragon flying over a futuristic city, cinematic lighting, volumetric fog, dramatic shadows, wide angle, shallow depth of field, teal and orange color grading, 3d render, unreal engine, 8k resolution, highly detailed, intricate details, sharp focus, masterpiece, rule of thirds composition, epic scale, cyberpunk aesthetic, neon lights, chrome texture
```

---

## 📦 Instalación en ComfyUI

1. Descargar modelo ZImage/Zigma
2. Colocar en: `ComfyUI/models/checkpoints/`
3. Usar nodo "Load Checkpoint" 
4. Conectar a KSampler o Hires Fix
5. Ajustar parámetros según guía

---

*Actualizado: 2026-03-21*

# 💰 Sistema de Finanzas

## Descripción
Sistema de seguimiento financiero con importación CSV, categorías y análisis.

## Ubicación
- **Backend:** `/root/.openclaw/workspace/mibimax-app/backend/server.py`
- **Frontend:** `/root/.openclaw/workspace/mibimax-app/frontend/src/views/Finanzas.vue`
- **DB:** PostgreSQL - tabla `transacciones`

## Formato CSV (Europeo)
```
FECHA;DESCRIPCION;IMPORTE;TIPO
31/01/2024;NOMINA;2500,00;INGRESO
15/02/2024;SUPERMERCADOS;-150,00;GASTO
```

## Reglas
- **Positivo = Ingreso**
- **Negativo = Gasto**
- **Detección de nómina:** "NOMINA" en descripción
- **Inversiones:** Categoría especial

## Endpoints API
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | /api/finanzas/summary | Resumen total |
| GET | /api/finanzas/transacciones | Lista filtrada |
| GET | /api/finanzas/categorias | Categorías |
| GET | /api/finanzas/periodos | Períodos disponibles |
| POST | /api/finanzas/import-new | Importar CSV |

## Años en DB
2023, 2024, 2025, 2026

## Actualizado
2026-03-18

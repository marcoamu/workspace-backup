# 🔐 Sistema de Autenticación

## Descripción
Login con JWT tokens y gestión de usuarios.

## Tabla
- **Nombre:** app_users
- **Campos:** id, username, password_hash, email, created_at

## Credenciales Admin
- **Usuario:** admin
- **Contraseña:** Control9capo8

## Seguridad
- **Encriptación:** bcrypt
- **Tokens:** JWT
- **Timeout:** 1 hora de inactividad

## Endpoints
| Endpoint | Método | Descripción |
|----------|--------|-------------|
| /api/login | POST | Iniciar sesión |
| /api/register | POST | Registrar usuario |

## Flujo
1. Usuario envía credentials
2. Backend verifica con bcrypt
3. Retorna JWT token
4. Frontend guarda en localStorage
5. auth-check.js valida en cada request

## Actualizado
2026-03-18

# 🤖 Sistema de Agentes

## Descripción
Sistema multiagente con LangGraph para automatización de tareas.

## Agentes
| Agente | Función |
|--------|---------|
| Research | Búsqueda y análisis |
| Finance | Datos financieros |
| Frontend | Desarrollo UI/UX |
| Backend | Desarrollo API/DB |

## Arquitectura
- **Orquestador:** LangGraph
- **Estado:** PostgreSQL (agent_tasks table)
- **Memoria:** Compartida entre agentes

## Endpoints
| Endpoint | Método | Descripción |
|----------|--------|-------------|
| /api/agents/process | POST | Procesar tarea |
| /api/agents/memory/{task_id} | GET | Ver memoria |
| /api/agents/status | GET | Estado de agentes |

## Ejecución
```bash
cd /root/.openclaw/workspace
source venv_langgraph/bin/activate
python scripts/kanban-orchestrator.py
```

## Actualizado
2026-03-18

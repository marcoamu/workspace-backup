# 🔍 Sistema de Investigación

## Descripción
Research database con Tavily search, pgvector embeddings y seguimiento de noticias.

## Componentes

### API de Búsqueda
- **Endpoint:** POST /api/research/search
- **Motor:** Tavily Search API
- **API Key:** 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

### RSS Feeds
- BBC Mundo
- Europa Press
- TechCrunch
- MIT Tech Review

### Base de Datos
- **investigaciones table:** AI research papers
- **research_links table:** Links guardados

### Cron Jobs
- News extraction: 7:00 AM daily
- YouTube research: 2:00 AM daily

## Herramientas
- Jina AI: Web scraping (https://r.jina.ai/[url])
- Ollama: Embeddings locales (llama3.2:1b)

## Actualizado
2026-03-18

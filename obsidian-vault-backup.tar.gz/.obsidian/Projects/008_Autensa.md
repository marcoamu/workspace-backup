# 🔧 Autensa (Mission Control)

## Descripción
AI Agent Orchestration Dashboard - interfaz visual para gestionar agentes de OpenClaw.

## Ubicación
- **Repo:** https://github.com/crshdn/mission-control
- **Local:** /root/.openclaw/workspace/autensa
- **Puerto:** 3002
- **URL:** http://212.227.107.120:3002

## Características
- Kanban para tareas (7 columnas)
- AI Planning con Q&A
- Agent System
- Live Feed en tiempo real
- Conexión WebSocket a OpenClaw

## Configuración
- Gateway: ws://127.0.0.1:18789
- Token: dcdb924ed67c7e0d3f6523e25630abc8c7d747028babd37f

## Tecnologías
- Next.js
- SQLite
- Socket.io

## Inicio
```bash
cd /root/.openclaw/workspace/autensa
PORT=3002 npm run dev
```

## Fecha
2026-03-18

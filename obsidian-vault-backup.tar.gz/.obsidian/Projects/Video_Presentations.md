# 🎬 Sistema de Presentaciones en Video

## Descripción
Sistema para generar videos dinámicos con gráficos y presentaciones automáticas.

## Tecnologías
- FFmpeg: Codificación de video
- Pillow (Python): Generación de imágenes
- ImageMagick: Frames
- edge-tts: Audio TTS

## Videos Generados
| Video | Archivo | Descripción |
|-------|---------|-------------|
| Iran-Israel | iran_elaborate.mp4 | Infográfico completo (20s) |
| Dashboard | dashboard.mp4 | Estadísticas |
| Stats | stats.mp4 | Gráficos animados |

## Cómo Generar
1. Crear frames PNG (1280x720)
2. Generar video: `ffmpeg -f concat -i frames.txt -c:v libx264 video.mp4`
3. Copiar a: `/root/.openclaw/workspace/mibimax-app/frontend/public/videos/`

## Tiempo
- Total: ~15-20 segundos

## Fecha
2026-03-18

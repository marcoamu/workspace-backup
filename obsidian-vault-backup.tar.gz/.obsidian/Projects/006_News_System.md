# 📰 Sistema de Noticias

## Descripción
Extracción y almacenamiento de noticias desde RSS feeds.

## Fuentes RSS
- BBC Mundo: https://feeds.bbci.co.uk/mundo/rss.xml
- Europa Press: https://www.europapress.es/rss
- TechCrunch: https://techcrunch.com/feed/
- MIT Tech Review: https://www.technologyreview.com/feed/

## Tabla
- **Nombre:** noticias
- **Campos:** titulo, descripcion, url, fuente, fecha, categoria

## Límites
- 20 noticias/día máximo
- Cron: 7:00 AM diario

## Extracción
- **Script:** /root/.openclaw/workspace/scripts/news-ai.py
- **API:** /api/news/*

## Actualizado
2026-03-18

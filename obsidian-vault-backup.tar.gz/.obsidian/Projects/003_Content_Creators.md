# 👥 Sistema de Creadores de Contenido

## Descripción
Gestión de creadores de TikTok, YouTube y LinkedIn con seguimiento de contenido.

## Tablas
- tiktok_creators
- youtube_creators
- linkedin_creators
- content_tracking

## Campos Creador
- username
- nombre
- bio
- seguidores
- url
- fecha_alta
- puntuacion (0-10)

## Contenido Seguido
- Título
- Descripción
- URL del video/post
- Fecha de publicación
- Extracción
- Transcripción
- Puntuación (1-5 estrellas)

## Endpoints
| Plataforma | Actualizar | Extraer Videos |
|------------|------------|----------------|
| TikTok | /api/creators/tiktok/{id}/actualizar | /api/creators/tiktok/{id}/extraer-videos |
| YouTube | /api/creators/youtube/{id}/actualizar | /api/creators/youtube/{id}/extraer-videos |
| LinkedIn | /api/creators/linkedin/{id}/actualizar | /api/creators/linkedin/{id}/extraer-videos |

## Extracción
- **Jina AI:** Scraping de URLs
- **yt-dlp:** Descarga de videos

## Actualizado
2026-03-18

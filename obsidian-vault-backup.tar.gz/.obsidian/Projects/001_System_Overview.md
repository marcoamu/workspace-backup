# 📡 Sistema OpenClaw - Visión General

## Información General
- **Nombre:** VPSMoncly
- **Modelo:** MiniMax-M2.5
- **Creado:** 2026

## Mi Humano
- **Nombre:** Monclair
- **Profesión:** Programador
- **Intereses:** IA, IA Generativa, Arquitectura de Software

## Infraestructura

### Servidor
| Servicio | IP | Puerto |
|----------|-----|--------|
| Frontend (Vue) | 212.227.107.120 | 3000 |
| Backend (FastAPI) | 212.227.107.120 | 8000 |
| Static Files | 212.227.107.120 | 4000 |
| Dashboard | 212.227.107.120 | 18789 |

### Base de Datos
- **Motor:** PostgreSQL
- **Nombre:** knowledge_base
- **Host:** localhost

### Tablas Principales
- transacciones (finanzas)
- tiktok_creators, youtube_creators, linkedin_creators
- content_tracking
- research_links
- app_users
- categorias_financieras
- agent_tasks
- noticias

## Tecnologías
- Frontend: Vue.js + Vite
- Backend: FastAPI (Python)
- Database: PostgreSQL + pgvector
- AI: MiniMax API
- Videos: FFmpeg + Pillow

## Credenciales
- **Admin:** admin / Control9capo8

## Estado
- ✅ Telegram conectado
- ✅ Frontend funcionando
- ✅ Backend funcionando
- ✅ Base de datos conectada

## Actualizado
2026-03-18

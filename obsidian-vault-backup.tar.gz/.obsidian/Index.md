# 📚 Obsidian Vault - OpenClaw

## 🎯 Proyectos
- [[001_System_Overview]] - Visión general del sistema
- [[002_Finance_System]] - Sistema de finanzas
- [[003_Content_Creators]] - Creadores de contenido
- [[004_Research_System]] - Sistema de investigación
- [[005_Agents_System]] - Agentes LangGraph
- [[006_News_System]] - Noticias RSS
- [[007_Auth_System]] - Autenticación
- [[008_Autensa]] - Autensa (Mission Control)
- [[Video_Presentations]] - Videos dinámicos

## 📁 Carpetas
- [[Memory]] - Memoria a largo plazo
- [[Tasks]] - Tareas
- [[Changes]] - Cambios importantes

## 👤 Sistema
- Usuario: Monclair
- AI: OpenClaw / MiniMax-M2.5
- IP: 212.227.107.120

## Actualizado
2026-03-18

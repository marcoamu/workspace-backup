# 🤖 OpenClaw Obsidian Vault

This vault is connected to OpenClaw AI assistant.

## Features
- 📝 Notes synced with AI
- 🔗 GitHub integration
- 🧠 Memory management

## Quick Links
- [[Memory]] - Long-term memory
- [[Tasks]] - Task management
- [[Research]] - Research notes

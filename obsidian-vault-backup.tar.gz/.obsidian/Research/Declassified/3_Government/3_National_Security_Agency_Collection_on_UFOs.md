# National Security Agency Collection on UFOs

**Fuente:** Government - National Archives  
**Fecha desclasificación:** 2024-02-20  
**Categoría:** UFO/Paranormal  
**Importancia:** medium  
**URL:** https://www.nsa.gov/Helpful-Links/NSA-FOIA/Frequently-Requested-Information/Unidentified-Flying-Objects-UFOs/

---

## Análisis



---

*Investigado el: 2026-04-05 10:32*

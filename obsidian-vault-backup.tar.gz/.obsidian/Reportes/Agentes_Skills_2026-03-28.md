# Reporte de Agentes, Skills y Tecnologías
**Fecha:** 28 Marzo 2026  
**Actualizado por:** VPSMoncly (MiniMax-M2.7)

---

## 🤖 AGENTES CONFIGURADOS

### 1. Claude Code Agents (Frontend/Backend)

| Agente | Función | Tecnología |
|--------|---------|------------|
| 🎨 Frontend Expert | UI/Vue/React/Tailwind | Claude CLI |
| ⚙️ Backend Expert | Python/FastAPI/DB/Docker | Claude CLI |

### 2. OpenClaw Main Agent

| Campo | Valor |
|-------|-------|
| **Modelo** | MiniMax-M2.7 |
| **Contexto** | 200K tokens |
| **Provider** | minimax (Coding Plan) |
| **Canal** | Telegram |
| **Estado** | ✅ Activo |

---

## 🛠️ SKILLS DISPONIBLES (58)

### OpenClaw Built-in Skills

| Categoría | Skills |
|-----------|--------|
| **AI & Agents** | ai-agent-helper, ai-agent-setup, agent-development, agent-orchestrator |
| **Desarrollo** | github, git-workflows, context-driven-development, task-workflow, senior-dev |
| **Frontend** | react, nextjs-expert, typescript, tailwindcss, ui-ux-design |
| **Backend** | nodejs, python-executor, api-dev, senior-backend |
| **Bases de Datos** | sql-toolkit, postgresql, mongodb, sqlite, supabase |
| **Docker** | docker, docker-compose, kubernetes, kubectl |
| **Web/Automation** | playwright-scraper, automation-workflows, jina-web-fetcher |
| **Búsqueda** | tavily-search, ddg-web-search, youtube, youtube-transcript |
| **Análisis** | data-analysis, ai-data-analysis, productivity |
| **Seguridad** | security-auditor, monitoring, sysadmin-toolbox |

---

## 📁 PROYECTOS PRINCIPALES

### mibimax-app
- Frontend: Vue.js + Vite
- Backend: FastAPI (Python)
- DB: PostgreSQL
- Vistas: 25
- APIs: 40+

---

## 🔧 SCRIPTS PRINCIPALES (87)

| Categoría | Count |
|-----------|-------|
| Agents | 15+ |
| Content | 10+ |
| Finance | 5+ |
| Research | 8+ |
| Alerts | 4+ |

---

## 🗄️ BASE DE DATOS

- Tablas: 42
- Tamaño: ~13MB

---

## 🌐 SERVICIOS ACTIVOS

| Servicio | Puerto |
|----------|--------|
| Frontend | 3000 |
| Backend | 8000 |
| PostgreSQL | 5432 |
| Redis | 6379 |

---

## 📊 CRONS

| Hora | Task |
|------|------|
| */2 min | Auto-restart |
| 30 * * * | Smart alerts |
| 0 9 * * * | Daily memory |
| 0 3 * * * | Auto-improve |

---

*Generado por VPSMoncly - 28/03/2026*

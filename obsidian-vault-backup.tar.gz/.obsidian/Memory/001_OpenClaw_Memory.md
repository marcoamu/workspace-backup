# 🤖 OpenClaw Memory

## About Me
- Name: VPSMoncly
- Model: MiniMax-M2.5
- Created: 2026

## My Human
- Name: Monclair
- Profession: Programmer
- Interests: AI, Generative AI, AI-focused software architecture

## System
- IP: 212.227.107.120
- Database: knowledge_base
- Frontend: Vue.js (port 3000)
- Backend: FastAPI (port 8000)

## Preferences
- Spanish language
- Free alternatives (Ollama, MyMemory, Tesseract)

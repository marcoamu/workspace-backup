# Token Optimization - MiniMax Coding Plan

## Estrategias Implementadas

### 1. Prompt Caching (MiniMax Built-in)
- MiniMax tiene caching automático de prompts
- Mejor usar prompts estáticos al inicio
- Contenido dinámico al final

### 2. Response Caching (Implementado)
- Ubicación: `/tmp/mibimax_cache`
- TTL: 1 hora (configurable)
- Key: SHA256 del prompt

### 3. APIS Implementadas

| Endpoint | Función |
|----------|---------|
| GET /api/cache/stats | Estadísticas de cache |
| POST /api/cache/clear | Limpiar cache |
| GET /api/cache/get?prompt=xxx | Obtener respuesta cached |
| POST /api/cache/track | Guardar respuesta |
| POST /api/prompts/optimize | Optimizar prompt |

### 4. Scripts Creados

- `rtk-wrapper.sh` - Reduce output de comandos
- `llm-cache.sh` - Cache de respuestas LLM

### 5. Recomendaciones

1. Usar prompts estáticos al inicio
2. Cachear respuestas repetitivas
3. Truncar historial de conversaciones
4. Comprimir contexto cuando sea posible
5. Usar RTK para comandos comunes

## Ahorro Potencial

- Cache hit: 0 tokens
- Sin cache: prompt completo cada vez
- Estimado: 30-60% reducción en tokens

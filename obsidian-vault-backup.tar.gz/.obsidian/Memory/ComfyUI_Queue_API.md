# ComfyUI Queue - API Documentation

## Sistema de Cola de Prompts

Nuestro sistema expone endpoints para que el otro OpenClaw recoja prompts y actualice el estado.

---

## 📡 ENDPOINTS

### Obtener prompts pendientes
```
GET http://212.227.107.120:8000/api/queue/pending
```

**Respuesta:**
```json
{
  "prompts": [
    {
      "id": 47,
      "idea": "Mujer guapa manejando...",
      "prompt": "Mujer guapa..., cinematic...",
      "estilo": "cinematic",
      "categoria": "general",
      "created_at": "2026-03-28T10:00:00"
    }
  ],
  "count": 5
}
```

### Reclamar un prompt (marcar como procesando)
```
POST http://212.227.107.120:8000/api/queue/{id}/claim
```

**Respuesta:**
```json
{"success": true, "prompt_id": 47, "status": "processing"}
```

### Marcar como completado con resultado
```
POST http://212.227.107.120:8000/api/queue/{id}/complete
Content-Type: application/json

{
  "media_url": "https://url-de-la-imagen.png",
  "local_path": "/path/local/imagen.png",
  "media_type": "image"
}
```

**Respuesta:**
```json
{"success": true, "prompt_id": 47, "status": "completed"}
```

### Ver procesados
```
GET http://212.227.107.120:8000/api/queue/processed
```

---

## 🔄 Flujo de Trabajo

1. **Nuestro sistema:** Añade prompts a la cola (botón 🖼️)
2. **Otro OpenClaw:** Poll `/api/queue/pending`
3. **Otro OpenClaw:** POST `/claim` para reclamar
4. **Otro OpenClaw:** Genera imagen/vídeo en ComfyUI
5. **Otro OpenClaw:** POST `/complete` con URL del resultado
6. **Nuestro sistema:** Muestra resultado en galería

---

## 📊 Estado de Prompts

| Estado | Descripción |
|--------|-------------|
| `pending` | Esperando en cola |
| `processing` | Reclamado por otro OpenClaw |
| `completed` | Con resultado (URL disponible) |

---

## 🛠️ Scripts de Ejemplo

### Python (otro OpenClaw)
```python
import requests
import time

HOST = "http://212.227.107.120:8000"

def process_queue():
    while True:
        # Get pending
        r = requests.get(f"{HOST}/api/queue/pending")
        pending = r.json()["prompts"]
        
        for p in pending:
            # Claim
            requests.post(f"{HOST}/api/queue/{p['id']}/claim")
            
            # Generate with ComfyUI
            result = generate_with_comfyui(p["prompt"])
            
            # Complete
            requests.post(
                f"{HOST}/api/queue/{p['id']}/complete",
                json={"media_url": result["url"], "media_type": "image"}
            )
        
        time.sleep(60)  # Poll cada minuto
```

---

## 📍 Configuración

- **Host:** http://212.227.107.120
- **Puerto API:** 8000
- **Base URL:** http://212.227.107.120:8000
